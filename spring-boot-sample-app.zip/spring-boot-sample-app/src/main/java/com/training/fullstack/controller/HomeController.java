package com.training.fullstack.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.fullstack.model.Employee;

@RestController
@RequestMapping("/api")
public class HomeController {
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello Springboot App";
	}
	@GetMapping("/employee")
	public List<Employee> getEmployee() {
		Employee employee1 = new Employee(101,"Yash", 50000, LocalDate.of(2003, 10, 1), true, 9087987987L);
		Employee employee2= new Employee(102,"Harsh", 30000, LocalDate.of(2010, 7, 5), true, 9087656987L);
		Employee employee3 = new Employee(103,"Ram", 64000, LocalDate.of(2011, 3, 4), true, 9087289387L);
		List<Employee> list = new ArrayList<>();
		list.add(employee1);
		list.add(employee2);
		list.add(employee3);
		return list;
	}
	
}
