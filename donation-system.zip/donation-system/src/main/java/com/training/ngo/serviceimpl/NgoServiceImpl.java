package com.training.ngo.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ngo.dto.NgoDto;
import com.training.ngo.entity.Ngo;
import com.training.ngo.repository.NgoRepository;
import com.training.ngo.service.NgoService;

@Service
public class NgoServiceImpl implements NgoService {
	@Autowired
	NgoRepository repository;
     
	@Override
	public NgoDto saveNgo(NgoDto ngodto) {
		Ngo ngo=new Ngo();
		BeanUtils.copyProperties(ngodto, ngo);
		repository.save(ngo);
		
		return ngodto;
	}

	@Override
	public NgoDto deleteNgo(int id) {
		NgoDto dto=getNgoById(id);
		Ngo ngo=new Ngo();
		BeanUtils.copyProperties(dto, ngo);
		repository.delete(ngo);
		return dto;
	}

	@Override
	public NgoDto getNgoById(int id) {
		Optional<Ngo> findById = repository.findById(id);
		if(findById.isPresent()) {
			NgoDto dto=new NgoDto();
			BeanUtils.copyProperties(findById.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public NgoDto updateNgo(int id, NgoDto ngodto) {
		NgoDto dto=getNgoById(id);
		if(ngodto.getNgoName().equals(dto.getNgoName())) {
			Ngo ngo=new Ngo();
			ngodto.setNgoId(id);
			BeanUtils.copyProperties(ngodto, ngo);
			repository.save(ngo);
			
		}
		return ngodto;
	}

	@Override
	public List<NgoDto> getAllNgos() {
		List<Ngo> findAll = repository.findAll();
		List<NgoDto> dtolist=new ArrayList<>();
		for(Ngo ngos:findAll) {
			NgoDto ngodto=new NgoDto();
			BeanUtils.copyProperties(ngos, ngodto);
			dtolist.add(ngodto);
		}
		return dtolist;
	}

}
