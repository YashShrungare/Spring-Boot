package com.training.ngo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.ngo.dto.NgoDto;
import com.training.ngo.impl.NgoServiceImpl;

@RestController
@RequestMapping("/api/ngos")
public class NgoController {
	@Autowired
	private NgoServiceImpl  service;
	@PostMapping
	public ResponseEntity<NgoDto> saveNgo(@RequestBody NgoDto ngodto) {
		NgoDto dto=service.saveNgo(ngodto);
		return new ResponseEntity<NgoDto>(dto,HttpStatus.OK);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<NgoDto> deleteNgo(@PathVariable int id) {
		NgoDto dto=service.deleteNgo(id);
		return new ResponseEntity<NgoDto>(dto,HttpStatus.OK);
	}
	@PutMapping("/{id}")
	public ResponseEntity<NgoDto> updateNgo(@PathVariable int id,@RequestBody NgoDto ngodto) {
		NgoDto dto=service.updateNgo(id,ngodto);
		return new ResponseEntity<NgoDto>(dto,HttpStatus.OK);
	}
	@GetMapping("/{id}")
	public ResponseEntity<NgoDto> getByIdNgo(@PathVariable int id) {
		NgoDto dto=service.getNgoById(id);
		return new ResponseEntity<NgoDto>(dto,HttpStatus.FOUND);
	}
	@GetMapping
	public ResponseEntity<List<NgoDto>> getAllNgos() {
		List<NgoDto> dtolist=service.getAllNgos();
		return new ResponseEntity<List<NgoDto>>(dtolist,HttpStatus.FOUND);
	}
	

}
