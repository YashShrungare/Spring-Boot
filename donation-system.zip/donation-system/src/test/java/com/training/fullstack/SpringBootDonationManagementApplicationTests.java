package com.training.fullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDonationManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
