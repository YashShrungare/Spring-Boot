package com.training.ngo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.ngo.dto.DonarDto;
import com.training.ngo.service.DonarService;

@RestController
public class DonarController {
	@Autowired
	private DonarService donarService;

	@PostMapping("/donars/register-donar")
	public ResponseEntity<DonarDto> addDonar(@RequestBody DonarDto donarDto) {
		DonarDto insertDonor = donarService.insertDonor(donarDto);
		return new ResponseEntity<DonarDto>(insertDonor, HttpStatus.OK);
	}

	@DeleteMapping("/donars/delete/{donarId}")
	public ResponseEntity<DonarDto> deleteDonar(@PathVariable Integer donarId) {
		DonarDto deleteDonor = donarService.deleteDonor(donarId);
		return new ResponseEntity<DonarDto>(deleteDonor, HttpStatus.OK);
	}

	@PutMapping("/donars/update-donar")
	public ResponseEntity<DonarDto> updateDonar(@RequestBody DonarDto dto) {
		DonarDto updateDonor = donarService.updateDonor(dto);
		return new ResponseEntity<DonarDto>(updateDonor, HttpStatus.OK);
	}

	@GetMapping("/donars/get/{donarId}")
	public ResponseEntity<DonarDto> getDonarById(@PathVariable Integer donarId) {
		DonarDto donarDto = donarService.getDonorById(donarId);
		return new ResponseEntity<DonarDto>(donarDto, HttpStatus.FOUND);
	}

	@GetMapping("donars/all")
	public ResponseEntity<List<DonarDto>> getAllDonars() {
		List<DonarDto> allDonars = donarService.getAllDonors();
		return new ResponseEntity<List<DonarDto>>(allDonars, HttpStatus.FOUND);
	}
}
