package com.training.ngo.service;

import java.util.List;

import com.training.ngo.dto.NgoDto;

public interface NgoService {
	public NgoDto insertNgo(NgoDto ngoDto);//for inserting ngos

	public NgoDto deleteNgo(Integer id);//for deleting ngos

	public NgoDto updateNgo(NgoDto ngoDto);//for updating ngos

	public NgoDto getNgoById(Integer id);//for fetching the ngo by id 

	public List<NgoDto> getAllNgos();//for fetching every ngo in table
}
