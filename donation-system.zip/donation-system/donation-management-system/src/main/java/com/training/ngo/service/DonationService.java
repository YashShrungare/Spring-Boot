package com.training.ngo.service;

import java.util.List;

import com.training.ngo.dto.DonationDto;

public interface DonationService {
	public DonationDto insertDonation(DonationDto donationDto);//for inserting new donations

	public List<DonationDto> getAllDonationsByNgo(DonationDto donationDto);//for fetching all donations in table
	
	public List<DonationDto> getAllDonationsByDonar(DonationDto donationDto);//for fetching all donations in table
}
