package com.training.ngo.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ngo.dto.DonarDto;
import com.training.ngo.entity.DonarEntity;
import com.training.ngo.repository.DonarRepository;
import com.training.ngo.service.DonarService;
@Service
public class DonarServiceImpl implements DonarService {

	@Autowired
	private DonarRepository repository;
	
	@Override
	public DonarDto insertDonor(DonarDto donarDto) {
		DonarEntity entity = new DonarEntity();
		BeanUtils.copyProperties(donarDto, entity);
		repository.save(entity);
		return donarDto;
	}

	@Override
	public DonarDto deleteDonor(Integer id) {
		DonarDto donarDto = getDonorById(id);
		DonarEntity donarEntity =new DonarEntity();
		BeanUtils.copyProperties(donarDto, donarEntity);
		repository.delete(donarEntity);
		return donarDto;
	}

	@Override
	public DonarDto updateDonor(DonarDto donarDto) {
		DonarDto dto = getDonorById(donarDto.getDonorId());
		DonarEntity donarEntity =new DonarEntity();
		BeanUtils.copyProperties(donarDto, donarEntity);
		repository.save(donarEntity);
		return dto;
	}

	@Override
	public DonarDto getDonorById(Integer id) {
		Optional<DonarEntity> optional = repository.findById(id);
		if(optional.isPresent()) {
			DonarDto donarDto = new DonarDto();
			BeanUtils.copyProperties(optional.get(), donarDto);
			return donarDto;
		}
		return null;
	}

	@Override
	public List<DonarDto> getAllDonors() {
		List<DonarEntity> entites = repository.findAll();
		List<DonarDto> dtos = new ArrayList<>();
		for(DonarEntity donarEntity:entites) {
			DonarDto donarDto = new DonarDto();
			BeanUtils.copyProperties(donarEntity, donarDto);
			dtos.add(donarDto);
		}
		return dtos;
	}

}
