package com.training.ngo.service.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ngo.dto.DonationDto;
import com.training.ngo.entity.Donation;
import com.training.ngo.repository.DonationRepository;
import com.training.ngo.service.DonationService;
@Service
public class DonationServiceImpl implements DonationService {

	@Autowired
	private DonationRepository repository;
	
	@Override
	public DonationDto insertDonation(DonationDto donationDto) {
		Donation entity = new Donation();//new Donation Entity object
		BeanUtils.copyProperties(donationDto, entity);//copying properties from dto to entity
		repository.save(entity);//insert operation
		return donationDto;
	}

	@Override
	public List<DonationDto> getAllDonationsByNgo(DonationDto donationDto) {
		
		return null;
	}

	@Override
	public List<DonationDto> getAllDonationsByDonar(DonationDto donationDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
