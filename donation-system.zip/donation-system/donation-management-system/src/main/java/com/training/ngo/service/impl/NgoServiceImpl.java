package com.training.ngo.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ngo.dto.NgoDto;
import com.training.ngo.entity.NgoEntity;
import com.training.ngo.repository.NgoRepository;
import com.training.ngo.service.NgoService;

@Service
public class NgoServiceImpl implements NgoService {
	@Autowired
	private NgoRepository repository;

	@Override
	public NgoDto insertNgo(NgoDto ngoDto) {
		NgoEntity entity = new NgoEntity();//new Ngo Entity object
		BeanUtils.copyProperties(ngoDto, entity);//copying properties from dto to entity
		repository.save(entity);//insert operation
		return ngoDto;
	}

	@Override
	public NgoDto deleteNgo(Integer id) {
		NgoDto ngoDto = getNgoById(id);     //calling the method implemented below 
		NgoEntity ngoEntity = new NgoEntity();	//creating empty ngo object
		BeanUtils.copyProperties(ngoDto, ngoEntity);   //copying from dto to entity
		repository.delete(ngoEntity);      // removing the entity
		return ngoDto;
	}

	@Override
	public NgoDto updateNgo(NgoDto ngoDto) {
		NgoDto dto = getNgoById(ngoDto.getNgoId()); //get dto by id passed inside of ngoDto
		NgoEntity entity =new NgoEntity();
		BeanUtils.copyProperties(ngoDto, entity);   //copying from dto to entity
		repository.save(entity);		//update 
		return dto;
	}

	@Override
	public NgoDto getNgoById(Integer id) {
		Optional<NgoEntity> optional = repository.findById(id);//fetch record from table
		if (optional.isPresent()) {
			NgoDto dto = new NgoDto();   
			BeanUtils.copyProperties(optional.get(), dto);//copy data from entity to dto
			return dto; //return dto
		}
		return null; //else return null
	}

	@Override
	public List<NgoDto> getAllNgos() {
		List<NgoEntity> listNgoEntity = repository.findAll();//fetch all from table
		List<NgoDto> ngoDtos = new ArrayList<>();// empty dto list
		for(NgoEntity entity:listNgoEntity) {
			NgoDto ngoDto =new NgoDto();     //dto object
			BeanUtils.copyProperties(entity,ngoDto);   //copy properties from entity to dto
			ngoDtos.add(ngoDto);   //add dto to list
		}
		return ngoDtos;  //return list
	}

}
