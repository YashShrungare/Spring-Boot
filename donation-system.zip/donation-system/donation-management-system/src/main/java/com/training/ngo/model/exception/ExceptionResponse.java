package com.training.ngo.model.exception;

public class ExceptionResponse extends Exception {
	private static final long serialVersionUID = 1L;

	public ExceptionResponse(String message) {
		super(message);
	}
}
