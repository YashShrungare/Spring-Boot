package com.training.ngo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.training.ngo")
public class DonationManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonationManagementSystemApplication.class, args);
	}

}
