package com.training.ngo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonationManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
