package com.training.ngo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.ngo.entity.DonationRequestEntity;

public interface DonationRequestRepository extends JpaRepository<DonationRequestEntity, Integer> {
	//for taking the implementations of basic CRUD operations
}
