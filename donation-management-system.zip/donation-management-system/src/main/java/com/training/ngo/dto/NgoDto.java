package com.training.ngo.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

public class NgoDto {
	private Integer ngoId;
	@NotBlank(message="Please enter the name")
	@Size(min=3, max=15,message= "The name should be min of 3 and max of 50 character")
	private String name;
	@NotBlank(message="please enter username")
	private String username;
	@NotNull(message = "please enter password")
	private String password;
	@NotBlank(message = "please enter address")
	private String address;
	@NotNull(message = "please enter phoneNo.")
	private Long phoneNo;
	@PastOrPresent(message = "please enter enddate")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate started;
	private String documents;

	public Integer getNgoId() {
		return ngoId;
	}

	public void setNgoId(Integer ngoId) {
		this.ngoId = ngoId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public LocalDate getStarted() {
		return started;
	}

	public void setStarted(LocalDate started) {
		this.started = started;
	}

	public String getDocuments() {
		return documents;
	}

	public void setDocuments(String documents) {
		this.documents = documents;
	}

}
