package com.training.ngo.service;

import java.util.List;

import com.training.ngo.dto.DonarDto;

public interface DonarService {
	public DonarDto insertDonor(DonarDto donarDto);

	public DonarDto deleteDonor(Integer id);

	public DonarDto updateDonor(DonarDto donarDto);

	public DonarDto getDonorById(Integer id);

	public List<DonarDto> getAllDonors();
}
