package com.training.ngo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.ngo.entity.NgoEntity;

public interface NgoRepository extends JpaRepository<NgoEntity, Integer>{
//for taking the implementations of basic CRUD operations
}
