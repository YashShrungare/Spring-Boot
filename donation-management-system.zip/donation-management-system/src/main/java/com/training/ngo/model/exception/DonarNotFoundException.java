package com.training.ngo.model.exception;

public class DonarNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DonarNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DonarNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
