package com.training.ngo.model.exception;

public class NgoNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NgoNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NgoNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
