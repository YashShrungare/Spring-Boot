package com.training.ngo.service;

import com.training.ngo.dto.DonationRequestDto;

public interface DonationRequestService {
	//for inserting new donation requests
	public DonationRequestDto insertDonationRequest(DonationRequestDto donationRequestDto);
	
	//for deleting donation request
	public DonationRequestDto deleteDonationRequest(DonationRequestDto donationRequestDto);

	//for updating donations
	public DonationRequestDto updateDonationRequest(Integer id);

	//for fetching donation request by id
	public DonationRequestDto getDonationRequestById(Integer id);

	//for fetching all donation requests
	public DonationRequestDto getAllDonationRequest(DonationRequestDto donationRequestDto);
}
