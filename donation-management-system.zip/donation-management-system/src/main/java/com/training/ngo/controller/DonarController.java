package com.training.ngo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.ngo.dto.DonarDto;
import com.training.ngo.dto.DonationDto;
import com.training.ngo.service.DonarService;
import com.training.ngo.service.DonationService;

@RestController
@RequestMapping("/ngos")
public class DonarController {
	@Autowired
	private DonarService donarService;
	@Autowired
	private DonationService donationService;

	@PostMapping("/donars/register-donar")
	public ResponseEntity<DonarDto> addDonar(@Valid @RequestBody DonarDto donarDto) {
		DonarDto insertDonor = donarService.insertDonor(donarDto);
		return new ResponseEntity<DonarDto>(insertDonor, HttpStatus.OK);
	}

	@DeleteMapping("/donars/delete/{donarId}")
	public ResponseEntity<DonarDto> deleteDonar(@PathVariable Integer donarId) {
		DonarDto deleteDonor = donarService.deleteDonor(donarId);
		return new ResponseEntity<DonarDto>(deleteDonor, HttpStatus.OK);
	}

	@PutMapping("/donars/update-donar")
	public ResponseEntity<DonarDto> updateDonar(@Valid @RequestBody DonarDto dto) {
		DonarDto updateDonor = donarService.updateDonor(dto);
		return new ResponseEntity<DonarDto>(updateDonor, HttpStatus.OK);
	}

	@GetMapping("/donars/get/{donarId}")
	public ResponseEntity<DonarDto> getDonarById(@PathVariable Integer donarId) {
		DonarDto donarDto = donarService.getDonorById(donarId);
		return new ResponseEntity<DonarDto>(donarDto, HttpStatus.FOUND);
	}

	@GetMapping("donars/all")
	public ResponseEntity<List<DonarDto>> getAllDonars() {
		List<DonarDto> allDonars = donarService.getAllDonors();
		return new ResponseEntity<List<DonarDto>>(allDonars, HttpStatus.FOUND);
	}
	
	
	//donation section
		
	
	@PostMapping("/donations/add-donation")
    public ResponseEntity<DonationDto> addDonation(@Valid @RequestBody DonationDto donationDto) {
        DonationDto insertDonation = donationService.insertDonation(donationDto);
        return new ResponseEntity<DonationDto>(insertDonation,HttpStatus.OK);
    }

    @PutMapping("/donations/update-donation")
    public ResponseEntity<DonationDto> updateDonation(@Valid @RequestBody DonationDto dto) {
        DonationDto updateDonation = donationService.updateDonation(dto);
        return new ResponseEntity<DonationDto>(updateDonation, HttpStatus.OK);
    }

    @DeleteMapping("/donations/delete/{donationId}")
    public ResponseEntity<DonationDto> deleteDonation(@RequestBody Integer donationId) {
        DonationDto deleteDonation = donationService.deleteDonation(donationId);
        return new ResponseEntity<DonationDto>(deleteDonation, HttpStatus.OK);
    }

    @GetMapping("/donations/get/{donationId}")
    public ResponseEntity<DonationDto> getDonationById(@RequestBody Integer donationId) {
        DonationDto byDonationId = donationService.getDonationById(donationId);
        return new ResponseEntity<DonationDto>(byDonationId, HttpStatus.OK);
    }

    @GetMapping("/donations/all")
    public ResponseEntity<DonationDto> getAllDonation(@RequestBody Integer donationId) {
        DonationDto byDonationId = donationService.getDonationById(donationId);
        return new ResponseEntity<DonationDto>(byDonationId, HttpStatus.OK);

    }
}