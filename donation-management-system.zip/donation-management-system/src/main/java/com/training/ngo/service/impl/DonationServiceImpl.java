package com.training.ngo.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.ngo.dto.DonationDto;
import com.training.ngo.entity.Donation;
import com.training.ngo.repository.DonationRepository;
import com.training.ngo.service.DonationService;
@Service
public class DonationServiceImpl implements DonationService {

	@Autowired
	private DonationRepository repository;
	
	@Override
	public DonationDto insertDonation(DonationDto donationDto) {
		Donation entity = new Donation();//new Donation Entity object
		BeanUtils.copyProperties(donationDto, entity);//copying properties from dto to entity
		repository.save(entity);//insert operation
		return donationDto;
	}


	@Override
    public DonationDto updateDonation(DonationDto dto) {
        Donation donation = new Donation();
        BeanUtils.copyProperties(dto, donation);
        repository.save(donation);
        return dto;

    }

	@Override
	public DonationDto deleteDonation(Integer id) {
		// TODO Auto-generated method stub
		DonationDto dto = getDonationById(id);
        Donation donation = new Donation();
        BeanUtils.copyProperties(dto, donation);
        repository.delete(donation);
        return dto;
		
	}

	@Override
	public DonationDto getDonationById(Integer id) {
		// TODO Auto-generated method stub
		Optional<Donation> findById = repository.findById(id);
        if (findById.isPresent()) {
            DonationDto dto = new DonationDto();
            BeanUtils.copyProperties(findById.get(), dto);
            return dto;
        }
		return null;
	}

	@Override

    public List<DonationDto> getAllDonation() {
        List<Donation> findAll = repository.findAll();
        List<DonationDto> dtos = new ArrayList<>();
        for (Donation donationEntity : findAll) {
            DonationDto dto = new DonationDto();
            BeanUtils.copyProperties(donationEntity, dto);
            dtos.add(dto);
        }
        return dtos;

    }
	
	
	@Override
	public List<DonationDto> getAllDonationsByNgo(DonationDto donationDto) {
		
		return null;
	}

	@Override
	public List<DonationDto> getAllDonationsByDonar(DonationDto donationDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
