package com.training.ngo.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DonationDto {
	private Integer donationId;
	
	@NotBlank(message = "Please enter the type of donation")
	private String type;
	
	@NotNull(message = "please enter amount")
	private Double amount;
	
	@PastOrPresent(message = "date should be present date")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate date;

	public Integer getDonationId() {
		return donationId;
	}

	public void setDonationId(Integer donationId) {
		this.donationId = donationId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

}
