package com.training.ngo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.ngo.dto.NgoDto;
import com.training.ngo.service.NgoService;

@RestController
@RequestMapping("/ngos")
public class NgoController {
	@Autowired
	private NgoService ngoService;

	@PostMapping("/register-ngo")
	public ResponseEntity<NgoDto> addNgo(@Valid @RequestBody NgoDto ngoDto) {
		NgoDto insertNgo = ngoService.insertNgo(ngoDto);
		return new ResponseEntity<NgoDto>(insertNgo, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{ngoId}")
	public ResponseEntity<NgoDto> deleteNgo(@PathVariable Integer ngoId) {
		NgoDto deleteNgo = ngoService.deleteNgo(ngoId);
		return new ResponseEntity<NgoDto>(deleteNgo, HttpStatus.OK);
	}

	@PutMapping("/update-ngo")
	public ResponseEntity<NgoDto> updateNgo(@Valid @RequestBody NgoDto dto){
		NgoDto updateNgo = ngoService.updateNgo(dto);
		return new ResponseEntity<NgoDto>(updateNgo, HttpStatus.OK);
	}
	
	@GetMapping("/get/{ngoId}")
	public ResponseEntity<NgoDto> getNgoById(@PathVariable Integer ngoId) {
		NgoDto ngoDto = ngoService.getNgoById(ngoId);
		return new ResponseEntity<NgoDto>(ngoDto, HttpStatus.FOUND);
	}

	@GetMapping("/all")
	public ResponseEntity<List<NgoDto>> getAllNgos() {
		List<NgoDto> allNgos = ngoService.getAllNgos();
		return new ResponseEntity<List<NgoDto>>(allNgos, HttpStatus.FOUND);
	}
}
