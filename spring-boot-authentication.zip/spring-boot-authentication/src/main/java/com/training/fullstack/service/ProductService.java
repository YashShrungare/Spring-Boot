package com.training.fullstack.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.training.fullstack.model.Product;
@Service
public class ProductService {
	
	
	List<Product> products = new ArrayList<>();
	@PostConstruct
	public void initialze() {
		products.add(new Product(101, "Laptop", 75000.0, "Hp Laptop"));
		products.add(new Product(102, "Headphone", 3000.0, "JBL Headphone"));
		products.add(new Product(103, "Mobile", 25000.0, "Kuba Mobile"));
		products.add(new Product(104, "Desktop", 85000.0, "Acer PC"));
	}
	public Product addProduct(Product product) {
		products.add(product);
		return product;
	}
	public Product updateProduct(Product product) {
		for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId().equals(product.getId())) {
                products.set(i, product);
                return product;
            }
		}
		return null;
	}
	public Product deleteProduct(Integer id) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId().equals(id)) {
                return products.remove(i);
            }
        }
        return null;
    }
	public Product getProductById(Integer id) {
		for (Product product : products) {
            if (product.getId().equals(id)) {
                return product;
            }
		}
		return null;
	}
	public List<Product> getAllProducts(){
		return products;
	}
}
