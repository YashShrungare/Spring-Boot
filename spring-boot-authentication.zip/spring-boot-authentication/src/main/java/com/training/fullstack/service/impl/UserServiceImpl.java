package com.training.fullstack.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.training.fullstack.entity.User;
import com.training.fullstack.repository.UserRepository;
import com.training.fullstack.service.UserService;
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository repository;
	
	@Autowired
	private PasswordEncoder encoder;

	@Override
	public User signUp(User user) {
		user.setPassword(encoder.encode(user.getPassword()));
		repository.save(user);
		return user;
	}

	@Override
	public Optional<User> findByUserName(String username) {
		Optional<User> findByName = repository.findByName(username);
		if(findByName.isPresent())
		{
			return Optional.of(findByName).get();
		}
		return null;
	}

}
