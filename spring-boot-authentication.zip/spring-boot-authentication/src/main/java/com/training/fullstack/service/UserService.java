package com.training.fullstack.service;

import java.util.Optional;

import com.training.fullstack.entity.User;

public interface UserService {
	User signUp(User user);
	Optional<User> findByUserName(String username);
}
