package com.training.fullstack.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.training.fullstack.entity.User;

public class LoginUserDetailsService implements UserDetailsService {
	@Autowired
	private UserService service;


	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> user = service.findByUserName(username);
		return user.map(LoginUserDetails::new).orElseThrow(()->new UsernameNotFoundException("not" +username));
	}

}
